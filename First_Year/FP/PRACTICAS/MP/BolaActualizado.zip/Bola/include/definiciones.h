/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   definiciones.h
 * Author: cristian
 *
 * Created on 7 de mayo de 2019, 22:52
 */

#ifndef DEFINICIONES_H
#define DEFINICIONES_H

const int UMBRAL=0;
const int MIN_X=799;
const int MIN_Y=599;
const int MAX_VEL=100;
const int RADIO = 20;

#endif /* DEFINICIONES_H */

