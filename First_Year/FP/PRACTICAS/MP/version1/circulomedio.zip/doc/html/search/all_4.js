var searchData=
[
  ['getcentro',['getCentro',['../classCirculo.html#a54f31597372c19c1cfa779ab17c8e99d',1,'Circulo']]],
  ['getradio',['getRadio',['../classCirculo.html#ae6eb1c38f2f2802a10d130c87caca383',1,'Circulo']]],
  ['getx',['getX',['../classPunto.html#a0b37a2333238d01ed3125826261a9654',1,'Punto']]],
  ['gety',['getY',['../classPunto.html#ad23e5570bd931af6f73ec0ede9511b27',1,'Punto']]]
];
