var searchData=
[
  ['set',['set',['../classCirculo.html#aa24cc4b316a3d9ece35f120d9b8e1fc4',1,'Circulo']]],
  ['setx',['setX',['../classPunto.html#a51ae6616f828bb2b4111bc8ace49dbca',1,'Punto']]],
  ['sety',['setY',['../classPunto.html#a6a0f8adb5946f31a7867a06f54d97462',1,'Punto']]]
];
