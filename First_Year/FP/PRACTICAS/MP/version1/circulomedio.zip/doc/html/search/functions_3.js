var searchData=
[
  ['escribir',['escribir',['../classPunto.html#a05322c20e6c4f8e61aaf91f8a5d4c21a',1,'Punto::escribir()'],['../classCirculo.html#a33d4f94063db04f131a92587b77754de',1,'Circulo::escribir()']]]
];
